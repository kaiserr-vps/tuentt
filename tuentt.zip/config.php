<?php
// Envio telegram
// true = SI | false = NO
$telegram_send = true;
$bottoken = "1741134638:AAHOIInahSctjTAOsoo44QuCU-eLv8ceMnI";
$chatid = "1330424033";

// Guardar archivo
// true = SI | false = NO
$file_save = false;

// Envio Gmail
// true = Si | false = NO
$email_send = false;
$email = "jasonidk@test.com";
?>